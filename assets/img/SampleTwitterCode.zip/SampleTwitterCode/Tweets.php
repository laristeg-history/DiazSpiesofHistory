<?php 
// Set all of the major app variables, including database access vars, database and formatting functions. NB: These dependencies not included in this packet.
	require("app_info_teaching.php");

	// Database call for Tweets with no parent ID. Feed these to an array.
	$Tweets = DBSelect("SELECT * FROM Prokopios_Twitter WHERE Twitter_ID > '0' AND Twitter_ReplyID < '1' ORDER BY Twitter_Citation ASC");

// Set up a Tweet display function to draw on later
function DisplayTweet($User, $Post, $TweetID, $ReplyTo_ID, $Citation, $Datestamp)
{
	$DisplayDate = date("M d, g:i", strtotime($Datestamp));
	
// Hack the CSS so that the Twitter app doesn't require anything other than the libraries above.
	echo <<<END
<p class="user">$User <p class="datestamp">($DisplayDate)</p>
<p>$Post <span class="citation">($Citation)</span> <span style="float:right"><a href="index.php?Reply_To=$ReplyTo_ID&ReplyTo_User=$User"><img border=0 src="img/ReplyTo.jpg"></a>
END;
}

echo <<<END
<html>
<head>
<!--<META HTTP-EQUIV="refresh" CONTENT="60">-->
<link href="stylesheets/jquery.cssemoticons.css" media="screen" rel="stylesheet" type="text/css" />
<script src="javascripts/jquery.js" type="text/javascript"></script>
<script src="javascripts/jquery.cssemoticons.js" type="text/javascript"></script>
<script type="text/javascript">
  $('.comment').emoticonize();
</script>

<style type="text/css" style="display: none !important;">
body, p, ul {
	font-family: arial, helvetica, sans-serif;
}
.comment {
	margin-left:1em;
	font-size:.9em;
}
.user {
	display:inline;
	margin: .5em 0 0 0;
	font-weight:bold;
}
.datestamp {
	display:inline;
	font-size: .8em;
	font-style:italic;
}
.citation {
	font-style:italic;
}
ul {
    background: #efefef;
    margin: .5em 3em 0 .5em;
}

hr {
    border: 0;
    height: 0;
    border-top: 1px solid #ffffff;
    border-bottom: 1px solid #dedede;
}
hr.style-three {
    border: 0;
    height: 0;
    border-top: 1px solid #ffffff;
    border-bottom: 1px solid #efefef;
}
</style>
</head>
<title>A Late Antique Twitter Feed (Prokopios as Social Media)</title>
<html>
<h1>A Late Antique Twitter Feed</h1>
<a href="./">Tweet something new</a>
<hr>
<div class="comment">
END;

// Extract the database-result array line by line
for ($I = 0; $I < DBNumRows($Tweets); $I++)
{
	extract($Tweets[$I]);
	// Use the function we set up on line 8
	DisplayTweet($Twitter_Usr, $Twitter_Post, $Twitter_ID, $Twitter_ID, $Twitter_Citation, $Twitter_DateStamp);
	// Database call for Tweets whose parent ID is the current Tweet. Feed these to an array.
	$TweetThread = DBSelect("SELECT * FROM Prokopios_Twitter WHERE Twitter_ReplyID = '$Twitter_ID' ORDER BY Twitter_DateStamp DESC");
	// If there are child Tweets, set up an indented thread.
	if (DBNumRows($TweetThread) > 0)
	{
		echo "<ul>";
		for ($J = 0; $J < DBNumRows($TweetThread); $J++)
		{
			// Loop through the Child Tweets
			extract($TweetThread[$J]);
			DisplayTweet($Twitter_Usr, $Twitter_Post, $Twitter_ID, $Tweets[$I]["Twitter_ID"], $Twitter_Citation, $Twitter_DateStamp);
			echo "<hr class=\"style-three\">";
		}
		echo "</ul>";
	}

echo "<hr>";

}

// Set up emoticon parsing.

echo <<<END
</div>

<script type="text/javascript">
  $('.comment').emoticonize();
</script>

END;

?>