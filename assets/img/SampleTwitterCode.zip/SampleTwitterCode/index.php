<?php
// Set all of the major app variables, including database access vars, database and formatting functions. NB: These dependencies not included in this packet.
	require("app_info_teaching.php");

// Hack the CSS so that the Twitter app doesn't require anything other than the libraries above.
	echo <<<END
<html>
<head>
<title>New Tweet (Prokopios as Social Media)</title>
<script language="javascript">
function limitChars(textarea, limit, infodiv)
{
	var text = textarea.value; 
	var textlength = text.length;
	var info = document.getElementById(infodiv);
	if(textlength < limit)
	{
		info.innerHTML = (limit - textlength);
		return true;
	}
	else if (textlength === 0)
	{
		info.innerHTML = '0';
		return true;
	}
	else
	{
		info.innerHTML = '-'+(textlength - limit);
		return true;
	}
}
</script>
<link href="stylesheets/jquery.cssemoticons.css" media="screen" rel="stylesheet" type="text/css" />
<script src="javascripts/jquery.js" type="text/javascript"></script>
<script src="javascripts/jquery.cssemoticons.js" type="text/javascript"></script>
<script type="text/javascript">
  $('.comment').emoticonize();
</script>
<style type="text/css" style="display: none !important;">
body, p, ul {
	font-family: arial, helvetica, sans-serif;
}
.comment {
	margin-left:1em;
	font-size:.9em;
}
.user {
	display:inline;
	margin: .5em 0 0 0;
	font-weight:bold;
}
.datestamp {
	display:inline;
	font-size: .8em;
	font-style:italic;
}
.citation {
	font-style:italic;
}
ul {
    background: #efefef;
    margin: .5em 3em 0 .5em;
}

hr {
    border: 0;
    height: 0;
    border-top: 1px solid #ffffff;
    border-bottom: 1px solid #dedede;
}
hr.style-three {
    border: 0;
    height: 0;
    border-top: 1px solid #ffffff;
    border-bottom: 1px solid #efefef;
}
</style>
</head>
<body>
<h1>New Tweet (Prokopios as Social Media)</h1>
<form action="" method="post">
END;


// Check to see if the user is submitting information from the previous page and set some necessary hidden form values if yes

	FormHidden("Action",$_REQUEST["Action"]);
	FormHidden("Target",2);
// Check if it's a reply-to Tweet, and if so set the parent-Tweet ID
	if ($_REQUEST["Reply_To"])
		{	FormHidden("Twitter_ReplyID",$_REQUEST["Reply_To"]);	}
// Check if it's a reply-to Tweet, and if so set the parent-Tweet user name
	if ($_REQUEST["ReplyTo_User"])
		{	$Twitter_Post="@".$_REQUEST["ReplyTo_User"]." ";	}

// Check if there's a target for the input or if the field vars are empty
	if ($_REQUEST["Target"])
	{
		// Prep the DB insert by setting the field names in an array
		$FieldArray = array("Twitter_Post", "Twitter_Usr", "Twitter_Citation", "Twitter_DateStamp");
		// Prep the DB insert by setting user input var array and checking for variable hacking
		$InputArray = array(CleanTextInput($_REQUEST["Twitter_Post"]), CleanTextInput($_REQUEST["Twitter_Usr"]),CleanTextInput($_REQUEST["Twitter_Citation"]), $Date_ODBCDateTime);
		if ($_REQUEST["Twitter_ReplyID"])
		{
			$FieldArray[] = "Twitter_ReplyID";
			$InputArray[] = CleanTextInput($_REQUEST["Twitter_ReplyID"]);			
		}
		// Insert the new Tweet
		$AddQuery = DBInsert("Prokopios_Twitter", $FieldArray, $InputArray);
		// Make sure the insert succeeded
		$result = mysql_query($AddQuery) or die("Query failed: $AddQuery<br>" . mysql_error());
		$_REQUEST = array();
		
		// Echo success to the user
		echo <<<END
	<hr>
	<b>{$_REQUEST["Twitter_Usr"]}</b>
	<div class="comment">
	  {$_REQUEST["Twitter_Post"]}
	</div>
	<script type="text/javascript">
	  $('.comment').emoticonize();
	</script>
END;
	}

// Print out a blank Tweet form
echo <<<END
Username: <input type=text name="Twitter_Usr" size=50>
<br>Tweet: <span id="charlimitinfo" style="color:#aa3333; font-weight:bold; font-family:Garamond">140</span>
<br><textarea name="Twitter_Post" id="Twitter_Post" onkeyup="limitChars(this, 140, 'charlimitinfo')" rows=5 cols=50>$Twitter_Post</textarea>
<br>Citation: <input type=text name="Twitter_Citation">
<p><input type=submit value="{$_REQUEST["Action"]} Post"><form>

<p><a href="Tweets.php">View all tweets</a>
END;


?>